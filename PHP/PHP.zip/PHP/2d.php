<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>2D Ödeme İşleme</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <?php include 'style.php'; ?>
</head>

<body>
    <?php include 'nav.php'; ?>

    <?php
    if (isset($_POST['process_payment'])) {
        // Temel değişkenleri tanımla
        $baseUrl = "https://testapp.halkode.com.tr/ccpayment/api/paySmart2D";
        include 'degisken.php';
        $total = $_POST['total'];
        $installments_number = $_POST['installments_number'];
        $currencyCode = "TRY";
        $invoice_id = $_POST['invoice_id'];
        $transaction_type = $_POST['transaction_type'];

        // Token isteği
        $tokenResponse = getToken($app_id, $appSecret);
        $decodedTokenResponse = json_decode($tokenResponse, true);

        if ($decodedTokenResponse['status_code'] == 100) {
            $token = $decodedTokenResponse['data']['token'];
        } else {
            echo "<p><strong>Hata:</strong> Token alınamadı. Lütfen bilgilerinizi kontrol ediniz.</p>";
            return;
        }

        // Formdan verileri topla
        $data = array(
            "cc_holder_name" => $_POST['cc_holder_name'],
            "cc_no" => $_POST['cc_no'],
            "expiry_month" => $_POST['expiry_month'],
            "expiry_year" => $_POST['expiry_year'],
            "cvv" => $_POST['cvv'],
            "currency_code" => $currencyCode,
            "installments_number" => $installments_number,
            "invoice_id" => $invoice_id,
            "invoice_description" => "FATURA TEST AÇIKLAMASI",
            "total" => $total,
            "merchant_key" => $merchantKey,
            "transaction_type" => $transaction_type,
            "items" => array(
                array(
                    "name" => "item",
                    "price" => $total,
                    "quantity" => 1,
                    "description" => "ürün açıklaması"
                )
            ),
            "name" => $_POST['cc_holder_name'],
            "surname" => "Dao",
            "payment_status" => 1,
            "hash_key" => generateHashKey($total, $installments_number, $currencyCode, $merchantKey, $invoice_id, $appSecret)
        );

        // API isteği gönder
        $ch = curl_init($baseUrl);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            "Authorization: Bearer $token"
        ));
        $jsonData = json_encode($data);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        // Yanıtı çözümle
        $decodedResponse = json_decode($response, true);

        // İşlem sonucu kontrolü
        $isSuccessful = isset($decodedResponse['status_code']) && $decodedResponse['status_code'] == 100; // API yanıtına göre başarı durumu

        echo "<div style='display: flex; align-items: center; justify-content: center; '>";
        echo "<img src='HALKODE_LOGO-01.png' alt='Halköde Logo' style='width: 150px; height: auto; margin-right: 20px;'>";

        // Başarılı veya başarısız mesajı
        if ($isSuccessful) {
            echo "<h3 style='color: #17456d; text-align: center;'>İşlem Başarılı</h3>";
        } else {
            echo "<h3 style='color: red; text-align: center;'>İşlem Başarısız</h3>";
        }

        echo "</div>";

        // Tablo bölümü
        echo "<div style='display: flex; justify-content: center; margin: 20px;'>";

        // Gönderilen veriler tablosu
        echo "<div style='margin-right: 10px; width: 45%;'>";
        echo "<table class='table table-bordered table-hover' style='width: 100%; background-color: #f8f9fa; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);'><thead class='thead-dark'><tr><th style='text-align: center;'>Parametre</th><th style='text-align: center;'>Değer</th></tr></thead><tbody>";
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $value = '<pre>' . json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . '</pre>';
            }
            echo "<tr><td style='vertical-align: top; text-align: center;'>$key</td><td style='vertical-align: top; text-align: center;'>$value</td></tr>";
        }
        echo "</tbody></table>";
        echo "</div>";

        // API yanıtı tablosu
        echo "<div style='margin-left: 10px; width: 50%;'>";
        echo "<table class='table table-bordered table-hover' style='width: 100%; background-color: #f8f9fa; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);'><thead class='thead-dark'><tr><th style='text-align: center;'>Parametre</th><th style='text-align: center;'>Değer</th></tr></thead><tbody>";
        if ($decodedResponse) {
            foreach ($decodedResponse as $key => $value) {
                if (is_array($value)) {
                    $value = '<pre>' . json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . '</pre>';
                }
                echo "<tr><td style='vertical-align: top; text-align: center;'>$key</td><td style='vertical-align: top; text-align: center;'>$value</td></tr>";
            }
        } else {
            echo "<tr><td colspan='2' style='text-align: center;'>Hata: Yanıt alınamadı.</td></tr>";
        }
        echo "</tbody></table>";
        echo "</div>";

        echo "</div>";
    } else {
        // Form gönderilmediğinde tüm sayfayı göster
        ?>
        <div class="container mt-4" style="display: flex; justify-content: center; align-items: center; height: 100vh;">
            <!-- Kredi Kartı Görseli -->
            <div class="credit-card-container" style="display: flex; justify-content: center; align-items: center;">
                <div class="credit-card" style="background-color: #0000FF; border-radius: 10px; color: white; width: 500px; height: 300px; position: relative; padding: 20px; box-sizing: border-box; transform-style: preserve-3d; transition: transform 0.6s;">
                    <div class="credit-card__front" style="position: absolute; width: 100%; height: 100%; backface-visibility: hidden;">
                        <div class="credit-card__number" id="card_number_display" style="font-size: 1.5em; letter-spacing: 2px; margin-bottom: 20px;">**** **** **** ****</div>
                        <div class="credit-card__name" id="card_name_display" style="font-size: 1.2em; text-transform: uppercase; margin-bottom: 20px;">Kart Üzerindeki İsim</div>
                        <div class="credit-card__expiry" style="font-size: 1.2em;">
                            <span id="card_expiry_month_display">MM</span>/<span id="card_expiry_year_display">YY</span>
                        </div>
                    </div>
                    <div class="credit-card__back" style="position: absolute; width: 100%; height: 100%; backface-visibility: hidden; transform: rotateY(180deg); display: flex; justify-content: center; align-items: center;">
                        <div id="card_cvv_display" style="font-size: 1.5em;">CVV</div>
                    </div>
                </div>
            </div>

            <!-- Form -->
            <form method="post" style="flex: 1; margin-left: 20px; background-color: #f8f9fa; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
                <span style="color:#17456d">
                    <h2>2D Ödeme İşleme Sorgulama</h2>
                </span>

                <!-- Fatura numarası otomatik oluşturuluyor -->
                <?php 
                // Fatura ID'si otomatik olarak oluşturuluyor
                $invoice_id = date('Ymd') . '-' . rand(1000, 9999);
                ?>

                <div class="form-group">
                    <label for="invoice_id" class="mt-2">Fatura Numarası:</label>
                    <input type="text" class="form-control" id="invoice_id" name="invoice_id" value="<?php echo $invoice_id; ?>" readonly style="margin-bottom: 10px;">
                </div>

                <div class="form-group">
                    <label for="cc_holder_name">Kart Üzerindeki İsim / Soyisim:</label>
                    <input type="text" class="form-control" id="cc_holder_name" name="cc_holder_name" required style="margin-bottom: 10px;">
                </div>
                <div class="form-group">
                    <label for="cc_no">Kart Numarası:</label>
                    <input type="text" class="form-control" id="cc_no" name="cc_no" required style="margin-bottom: 10px;">
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="expiry_month">Son Kullanım Ayı (AA):</label>
                        <input type="text" class="form-control" id="expiry_month" name="expiry_month" required style="margin-bottom: 10px;">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="expiry_year">Son Kullanım Yılı (YY):</label>
                        <input type="text" class="form-control" id="expiry_year" name="expiry_year" required style="margin-bottom: 10px;">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="cvv">CVV:</label>
                        <input type="text" class="form-control" id="cvv" name="cvv" required style="margin-bottom: 10px;">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="total">Tutar:</label>
                        <input type="text" class="form-control" id="total" name="total" required style="margin-bottom: 10px;">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="installments_number">Taksit Sayısını Seçiniz:</label>
                        <select class="form-control" id="installments_number" name="installments_number" required style="margin-bottom: 10px;">
                            <!-- Taksit seçenekleri burada PHP tarafından dinamik olarak eklenecek -->
                        </select>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="transaction_type">İşlem Tipi:</label>
                        <select class="form-control" id="transaction_type" name="transaction_type" required style="margin-bottom: 10px;">
                            <option value="Auth">Auth</option>
                            <option value="PreAuth">PreAuth</option>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="invoice_description">Fatura Açıklaması:</label>
                        <input type="text" class="form-control" id="invoice_description" name="invoice_description" required style="margin-bottom: 10px;">
                    </div>

                </div>

                <button type="submit" name="process_payment" class="btn btn-primary" style="width: 100%;">Ödemeyi Gönder</button>
            </form>
        </div>
        <?php
    }
    ?>

    <?php include 'footer.php'; ?>
</body>

</html>

<script>
// Kart numarasına göre taksit seçeneklerini güncelleyen JS fonksiyonu
function updateInstallments() {
    var cardNumber = document.getElementById("cc_no").value.slice(0, 6); // Kart numarasının ilk 6 hanesini alıyoruz
    var installmentsSelect = document.getElementById("installments_number");
    installmentsSelect.innerHTML = ''; // Önceki taksit seçeneklerini temizliyoruz
    
    // Bankaya ait taksit sayısı
    var bankInstallments = {
        '415514': 3, // Halkbank
        '435678': 6, // İş Bankası örnek
        '455698': 4  // Garanti örnek
    };
    
    // Banka taksit seçeneklerine göre formu güncelliyoruz
    var maxInstallments = bankInstallments[cardNumber] || 1; // Varsayılan taksit sayısı 1
    for (var i = 1; i <= maxInstallments; i++) {
        var option = document.createElement("option");
        option.value = i;
        option.text = i + " Taksit";
        installmentsSelect.appendChild(option);
    }
}

// Kart numarası alanına her giriş yapıldığında taksit seçeneklerini güncelle
document.getElementById('cc_no').addEventListener('input', function() {
    var cardNumber = this.value.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim();
    document.getElementById('cc_no').value = cardNumber; // Kart numarasını düzgün formatta göster

    updateInstallments(); // Taksit seçeneklerini güncelle
});
</script>
