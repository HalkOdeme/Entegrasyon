<?php
$app_id = "f77c7d06a417638ccde51c35fd6f6c17";
$appSecret = "30296568e1d7941de4fd684dbc7203e4";
$merchantKey = '$2y$10$XUmbnOQ0nmHsZy8WxIno4euYobTVUzxqtU1h..x32zyfG6qw7OYrq';
?>
