<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>2D Ödeme İşleme Sorgulama</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <?php include 'style_index.php'; ?>
</head>

<body>
    <div class="background-image"></div>

    <?php include 'nav.php'; ?>

    <div class="content">
        <h1>Halk Elektronik Para ve Ödeme Hizmetleri PHP Entegrasyonuna Hoş Geldiniz</h1>
    </div>

    <?php include 'footer.php'; ?>
</body>

</html>