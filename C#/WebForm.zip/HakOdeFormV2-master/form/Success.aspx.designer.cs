﻿//------------------------------------------------------------------------------
// <otomatik olarak oluşturulmuş>
//     Bu kod bir araç tarafından oluşturuldu.
//
//     Bu dosyada yapılacak değişiklikler hatalı davranışa neden olabilir ve
//     kod tekrar üretildi. 
// </otomatik olarak oluşturulmuş>
//------------------------------------------------------------------------------

namespace form
{


    public partial class Success
    {

        /// <summary>
        /// lblCardNumber denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblCardNumber;

        /// <summary>
        /// lblInvoiceId denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblInvoiceId;

        /// <summary>
        /// lblStatusCode denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblStatusCode;

        /// <summary>
        /// lblStatusDescription denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblStatusDescription;

        /// <summary>
        /// apiResponseContainer denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlGenericControl apiResponseContainer;
    }
}
