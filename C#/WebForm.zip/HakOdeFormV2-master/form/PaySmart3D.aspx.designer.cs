﻿//------------------------------------------------------------------------------
// <otomatik olarak oluşturulmuş>
//     Bu kod bir araç tarafından oluşturuldu.
//
//     Bu dosyada yapılacak değişiklikler hatalı davranışa neden olabilir ve
//     kod tekrar üretildi. 
// </otomatik olarak oluşturulmuş>
//------------------------------------------------------------------------------

namespace form
{


    public partial class PaySmart3D
    {

        /// <summary>
        /// cardHolderName denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox cardHolderName;

        /// <summary>
        /// totalAmount denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox totalAmount;

        /// <summary>
        /// cardNumber denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox cardNumber;

        /// <summary>
        /// expiryMonth denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox expiryMonth;

        /// <summary>
        /// expiryYear denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox expiryYear;

        /// <summary>
        /// cvv denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox cvv;

        /// <summary>
        /// installments denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList installments;

        /// <summary>
        /// btnPay denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button btnPay;

        /// <summary>
        /// lblResult denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblResult;

        /// <summary>
        /// apiResponseContainer denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlGenericControl apiResponseContainer;
    }
}
