﻿namespace form
{
    public class ApiSettings
    {
        public string AppId { get; set; }
        public string AppSecret { get; set; }
        public string BaseAddress { get; set; }
        public string MerchantKey { get; set; }
        public string TokenUrls { get; set; }
    }
}
