﻿namespace HalkOdePaymentIntegration.Contract.Request
{
    public class InstallmentRequest
    {
        public string merchant_key { get; set; }
    }
}
