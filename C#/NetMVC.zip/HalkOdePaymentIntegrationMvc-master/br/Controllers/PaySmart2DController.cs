﻿using HalkOdePaymentIntegration.Contract.Request;
using HalkOdePaymentIntegration.Contract.Response;
using HalkOdePaymentIntegration.Generate;
using HalkOdePaymentIntegration.Settings;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;

namespace HalkOdePaymentIntegration.Controllers
{
    public class PaySmart2DController : Controller
    {
        private const string BaseUrl = "https://testapp.halkode.com.tr/ccpayment/api/";
        private const string URL = "paySmart2D";
        private readonly HttpClient _httpClient;
        private readonly ApiSettings _apiSettings;

        public PaySmart2DController()
        {
            _httpClient = new HttpClient();
            _apiSettings = new ApiSettingConfiguration().Configuration();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ProcessPayment(string cc_holder_name, string cc_no, string expiry_month, string expiry_year, string cvv, string currency_code, int installments_number, string invoice_description, double total, string item_name, double item_price, int item_quantity, string item_description, string name, string surname, string transaction_type)
        {
            if (total <= 0)
            {
                ModelState.AddModelError("total", "The total must be greater than 0.");
                return View("Index");
            }

            var paySmart2DRequest = CreateRequestParameter(_apiSettings, cc_holder_name, cc_no, expiry_month, expiry_year, cvv, currency_code, installments_number, invoice_description, total, item_name, item_price, item_quantity, item_description, name, surname, transaction_type);
            var response = await GetAsync(paySmart2DRequest);

            ViewBag.RequestData = paySmart2DRequest;
            ViewBag.ResponseData = response;

            return View("Index");
        }

        [HttpGet]
        public async Task<IActionResult> GetInstallmentOptions(string cc_no, double total)
        {
            var tokenResponse = await new TokenController().GetAsync();
            if (tokenResponse == null || string.IsNullOrEmpty(tokenResponse?.data?.token))
            {
                return Json(new { success = false, message = "Token alınamadı." });
            }

            var requestData = new
            {
                credit_card = cc_no,
                currency_code = "TRY",
                amount = total,
                merchant_key = _apiSettings.MerchantKey
            };

            var jsonRequest = JsonSerializer.Serialize(requestData);
            var httpContent = new StringContent(jsonRequest, Encoding.UTF8, "application/json");
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", tokenResponse.data.token);

            try
            {
                var httpResponse = await _httpClient.PostAsync($"{BaseUrl}getpos", httpContent);
                var jsonResponse = await httpResponse.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<GetPosResponse>(jsonResponse);

                if (result != null && result.status_code == 100 && result.data != null && result.data.Length > 0)
                {
                    return Json(new { success = true, options = result.data });
                }

                return Json(new { success = false, message = "Taksit seçenekleri bulunamadı." });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"GetPos API Hatası: {ex.Message}" });
            }
        }

        private async Task<PaySmart2DResponse> GetAsync(PaySmart2DRequest paySmart2DRequest)
        {
            var tokenResponse = await new TokenController().GetAsync();
            var jsonRequest = JsonSerializer.Serialize(paySmart2DRequest);

            var httpContent = new StringContent(jsonRequest, Encoding.UTF8, "application/json");
            _httpClient.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", tokenResponse?.data?.token);

            try
            {
                var httpResponse = await _httpClient.PostAsync($"{BaseUrl}{URL}", httpContent);
                var jsonResponse = await httpResponse.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<PaySmart2DResponse>(jsonResponse);
            }
            catch (Exception ex)
            {
                throw new Exception($"Hata: {ex.Message}");
            }
        }

        private PaySmart2DRequest CreateRequestParameter(ApiSettings apiSettings, string cc_holder_name, string cc_no, string expiry_month, string expiry_year, string cvv, string currency_code, int installments_number, string invoice_description, double total, string item_name, double item_price, int item_quantity, string item_description, string name, string surname, string transaction_type)
        {
            var paySmart2DRequest = new PaySmart2DRequest
            {
                cc_holder_name = cc_holder_name,
                cc_no = cc_no,
                expiry_month = expiry_month,
                expiry_year = expiry_year,
                cvv = cvv,
                currency_code = "TRY",
                installments_number = installments_number,
                invoice_id = InvoiceGenerator.GenerateInvoiceId(),
                invoice_description = invoice_description,
                total = total,
                items = new List<Item2D>
                     {
                      new Item2D { name = "item", price = total, quantity = 1, description = invoice_description }
                     },
                name = "John",
                surname = "Dao",
                merchant_key = apiSettings.MerchantKey,
                transaction_type = "Auth",
            };

            var hashGenerator = new HashGenerator();
            paySmart2DRequest.hash_key = hashGenerator.GenerateHashKey(
                false,
                paySmart2DRequest.total.ToString().Replace(",", "."),
                paySmart2DRequest.installments_number.ToString(),
                paySmart2DRequest.currency_code,
                paySmart2DRequest.merchant_key,
                paySmart2DRequest.invoice_id);

            return paySmart2DRequest;
        }
    }

    // GetPos API'nin dönüş tipini temsil eden model
    public class GetPosResponse
    {
        public int status_code { get; set; }
        public string status_description { get; set; }
        public InstallmentOption[] data { get; set; }
    }

    public class InstallmentOption
    {
        public int installments_number { get; set; }
        public string title { get; set; }
    }
}
