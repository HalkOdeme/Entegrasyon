﻿namespace HalkOdePaymentIntegration.Controllers
{
    internal class CardInfo
    {
        public string CardProgram { get; set; }
        public dynamic Banks { get; set; }
        public dynamic Installments { get; set; }
        public dynamic Logo { get; set; }
    }
}