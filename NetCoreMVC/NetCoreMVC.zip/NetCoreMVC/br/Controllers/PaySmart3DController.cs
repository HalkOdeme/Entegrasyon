﻿using HalkOdePaymentIntegration.Contract.Request;
using HalkOdePaymentIntegration.Contract.Response;
using HalkOdePaymentIntegration.Generate;
using HalkOdePaymentIntegration.Settings;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;

namespace HalkOdePaymentIntegration.Controllers
{
    public class PaySmart3DController : Controller
    {
        private const string URL = "api/paySmart3D";
        private readonly HttpClient _httpClient;
        private readonly ApiSettings _apiSettings;

        public PaySmart3DController()
        {
            _httpClient = new HttpClient();
            _apiSettings = new ApiSettingConfiguration().Configuration();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ProcessPayment(string cc_holder_name, string cc_no, string expiry_month, string expiry_year, string cvv, string currency_code, int installments_number, string invoice_description, double total, string item_name, double item_price, int item_quantity, string item_description, string name, string surname, string payment_completed_by, string transaction_type)
        {
            var return_url = Url.Action("Index", "Succes", null, Request.Scheme);
            var cancel_url = Url.Action("Index", "Fail", null, Request.Scheme);
            var paySmart3DRequest = CreateRequestParameter(_apiSettings, cc_holder_name, cc_no, expiry_month, expiry_year, cvv, currency_code, installments_number, invoice_description, total, item_name, item_price, item_quantity, item_description, name, surname, return_url, cancel_url, payment_completed_by, transaction_type);
            var response = await GetAsync(paySmart3DRequest);

            ViewBag.RequestData = paySmart3DRequest;
            ViewBag.ResponseData = response;

            return View("Index");
        }

        private async Task<string> GetAsync(PaySmart3DRequest paySmart3DRequest)
        {
            var tokenResponse = await new TokenController().GetAsync();
            var jsonRequest = JsonSerializer.Serialize(paySmart3DRequest);

            var httpContent = new StringContent(jsonRequest, Encoding.UTF8, "application/json");
            _httpClient.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", tokenResponse?.data?.token);

            try
            {
                var httpResponse = await _httpClient.PostAsync($"{_apiSettings.BaseAddress}{URL}", httpContent);
                var responseContent = await httpResponse.Content.ReadAsStringAsync();

                Console.WriteLine("Response: " + responseContent);

                if (responseContent.StartsWith("<"))
                {
                    return responseContent;
                }

                var jsonResponse = JsonSerializer.Deserialize<Dictionary<string, string>>(responseContent);
                return JsonSerializer.Serialize(jsonResponse);
            }
            catch (Exception ex)
            {
                throw new Exception($"Hata: {ex.Message}");
            }
        }

        private PaySmart3DRequest CreateRequestParameter(ApiSettings apiSettings, string cc_holder_name, string cc_no, string expiry_month, string expiry_year, string cvv, string currency_code, int installments_number, string invoice_description, double total, string item_name, double item_price, int item_quantity, string item_description, string name, string surname, string return_url, string cancel_url, string payment_completed_by, string transaction_type)
        {
            var paySmart3DRequest = new PaySmart3DRequest
            {
                cc_holder_name = cc_holder_name,
                cc_no = cc_no,
                expiry_month = expiry_month,
                expiry_year = expiry_year,
                currency_code = "TRY",
                installments_number = installments_number,
                invoice_id = InvoiceGenerator.GenerateInvoiceId(),
                invoice_description = invoice_description,
                total = total,
                items = new List<Item3D>
                {
                    new Item3D
                    {
                        name = "Item3",
                        price = total,
                        quantity = 1,
                        description = invoice_description
                    }
                },
                name =  "John",
                surname = "Dao",
                return_url = return_url,
                cancel_url = cancel_url,
                payment_completed_by = "app",
                cvv = cvv,
                merchant_key = apiSettings.MerchantKey,
                transaction_type = transaction_type
            };

            var hashGenerator = new HashGenerator();
            paySmart3DRequest.hash_key = hashGenerator.GenerateHashKey(
                false,
                paySmart3DRequest.total.ToString().Replace(",", "."),
                paySmart3DRequest.installments_number.ToString(),
                paySmart3DRequest.currency_code,
                paySmart3DRequest.merchant_key,
                paySmart3DRequest.invoice_id);

            return paySmart3DRequest;
        }
    }
}