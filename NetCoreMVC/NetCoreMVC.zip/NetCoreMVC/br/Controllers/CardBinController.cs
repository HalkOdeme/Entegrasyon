﻿namespace HalkOdePaymentIntegration.Controllers
{
    public class CardBinController
    {
    }
}
