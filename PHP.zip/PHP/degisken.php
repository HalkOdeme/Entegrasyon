<?php
$app_id = "006f074e818c52970b4212a4767181f3";
$appSecret = "ff486ce745834e39ed38908cdd7ceaaf";
$merchantKey = '$2y$10$tA5Q5IJJv8zpSh0sM.6bueB53HG2VmEKdWnj.HGewu9y5VUk7qvee';
?>
