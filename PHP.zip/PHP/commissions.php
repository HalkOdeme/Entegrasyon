<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>2D Ödeme İşleme Sorgulama</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <?php include 'style.php'; ?>
</head>

<body>

<?php include 'nav.php'; ?>
<div class="container mt-4">
      <h2 >Mevcut Komisyon</h2>

      <!-- HTML Form for User Input -->
      <form method="post">
          <div class="form-group">
          <label for="currency_code">Komisyon:</label>
              <input type="text" id="currency_code" placeholder="***" onkeydown="return /[a-z]/i.test(event.key)" maxlength="3" name="currency_code" value="" class="form-control" required>
           </div>
          <button type="submit" name="process_payment" class="btns">Mevcut Komisyonu Göster</button>
      </form>
  </div>
    <?php
        if (isset($_POST['process_payment'])) {
            // Temel değişkenleri tanımla
           
            $baseUrl = "https://testapp.halkode.com.tr/ccpayment/api/commissions";
            include 'degisken.php';
            $currency_code = $_POST['currency_code'];  // Formdan alınan para birimi kodu

            // Token isteği
            $tokenResponse = getToken($app_id, $appSecret);
            $decodedTokenResponse = json_decode($tokenResponse, true);

            if ($decodedTokenResponse['status_code'] == 100) {
                $token = $decodedTokenResponse['data']['token'];
            } else {
                echo "<p><strong>Hata:</strong> Token alınamadı. Lütfen bilgilerinizi kontrol ediniz.</p>";
                return;
            }

            // Formdan verileri topla
            $data = array(
                "currency_code" => $currency_code,
            );

            // Gönderilen verileri göster
            echo "<h3>Gönderilen Veriler</h3>";
            echo "<pre>" . htmlspecialchars(json_encode($data, JSON_PRETTY_PRINT)) . "</pre>";

            // Ödeme isteğini göndermek için CURL
            $ch = curl_init($baseUrl);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                "Authorization: Bearer $token"
            ));
            $jsonData = json_encode($data);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);

            // Yanıtı göster
            echo "<h3>Yanıt</h3><pre>" . htmlspecialchars($response) . "</pre>";
        }

        function generateHashKey($total, $installment, $currency_code, $merchant_key, $invoice_id, $app_secret) {
            // Bu fonksiyon kullanılmıyor gibi görünüyor, dolayısıyla kaldırabilirsiniz.
        }

        function getToken($app_id, $app_secret) {
            $baseUrl = "https://testapp.halkode.com.tr/ccpayment/api/token";
            $data = array('app_id' => $app_id, 'app_secret' => $app_secret);
            $jsonData = json_encode($data);
            $ch = curl_init($baseUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            $response = curl_exec($ch);
            curl_close($ch);
            return $response;
        }
    ?>

    <?php include 'footer.php'; ?>


</body>

</html>
