<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anasayfa</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            overflow: hidden;
        }

        .content {
            flex: 1;
            position: relative;
            text-align: center;
            color: white;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
        }

        .background-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('mainSlider1.jpg');
            background-size: cover;
            background-position: center;
            z-index: 0;
        }

        .content h1 {
            position: relative;
            z-index: 1;
            margin-top: 50px;
        }

        .navbar-custom {
            background-color: #1b0565;
        }

        .navbar-custom .nav-link {
            color: white !important;
        }

        .navbar-brand {
            flex-grow: 1;
            text-align: center;
        }

        .navbar-nav {
            flex-direction: row;
            justify-content: center;
            width: 100%;
        }

        footer {
            background-color: #1b0565;
            color: white;
        }
    </style>
</head>

<body>
  <?php include "nav.php" ?>

    <div class="content">
        <div class="background-image"></div>
        <h1>Halk Elektronik Para ve Ödeme Hizmetleri PHP Entegrasyonuna Hoş Geldiniz</h1>
    </div>

    <footer class="text-center text-lg-start">
        <div class="text-center p-3">
            <span>© Halk Elektronik Para ve Ödeme Hizmetleri A.Ş</span>
        </div>
    </footer>

    <!-- Include jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

    <!-- Smooth Scroll Script -->
    <script>
        $(document).ready(function() {
            $('.navbar-toggler').on('click', function() {
                $('html, body').animate({
                    scrollTop: $('.content').offset().top
                }, 800); // 800ms smooth scroll
            });
        });
    </script>
</body>

</html>