<style>
    body {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .container {
        flex: 1;

    }

    .navbar-custom {
        background-color: #1b0565;
    }

    .navbar-custom .nav-link {
        color: white !important;
    }

    .navbar-brand {
        flex-grow: 1;
        text-align: center;
    }

    .navbar-nav {
        flex-direction: row;
        justify-content: center;
        width: 100%;
    }

    footer {
        background-color: #1b0565;
        color: white;
    }

    .btn-custom {
        background-color: #1b0565;
        color: white;
    }

    .btns {

        margin-bottom: 10px;
        padding: 15px 25px;
        font-size: 14px;
        text-align: center;
        cursor: pointer;
        outline: none;
        color: #fff;
        background-color: #1b0565;
        border: none;
        border-radius: 15px;

    }


    td {
        word-wrap: break-word;
        word-break: break-word;
        max-width: 250px;
    }

    .form-container {
            background-image: url('visa-gold-card-498x280.png');
            background-size: cover;
            background-position: center;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            position: relative;
            color: white;
            margin-bottom: 20px;
            height: 250px;
            width: 405px;
            margin: 0 auto;
            transition: transform 0.6s;
            transform-style: preserve-3d;
        }

        .form-background {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
        }

        .card-details,
        .card-back {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 1.2em;
      
            padding: 10px;
            border-radius: 10px;
            color: white;
            text-align: center;
        }

        .card-details .card-number,
        .card-details .card-holder,
        .card-details .card-expiry {
            margin-bottom: 10px;
        }

        .card-back {
            display: none;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
        }

        .form-container.flipped .card-details {
            display: none;
        }

        .form-container.flipped .card-back {
            display: block;
        }
</style>