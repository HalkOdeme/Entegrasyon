<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>Token</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .container {
            flex: 1;
        }

        .navbar-custom {
            background-color: #1b0565;
        }

        .navbar-custom .nav-link {
            color: white !important;
        }

        .navbar-brand {
            flex-grow: 1;
            text-align: center;
        }

        .navbar-nav {
            flex-direction: row;
            justify-content: center;
            width: 100%;
        }

        footer {
            background-color: #1b0565;
            color: white;
        }

        .btn-custom {
            background-color: #1b0565;
            color: white;
        }

        .btn {
            background-color: #1b0565;
            color: white;

        
        }

        td {
            word-wrap: break-word;
            word-break: break-word;
            max-width: 250px;
        }

    </style>
</head>

<body>
<?php include "nav.php" ?>

    <div class="container mt-4">
    <?php include 'style.php'; ?>
        <h2 class="baslik">Token</h2>

        <!-- HTML Form for User Input -->
        <form method="post">

            <button type="submit" name="process_payment" class="btns mt-2">Token Al</button>
        </form>

        <?php
        if (isset($_POST['process_payment'])) {

            date_default_timezone_set('Europe/Istanbul');
            $app_id = "6a2837927bd20097840c985c144c8399";
            $appSecret = "ef987418d46cad78b60c1f645780f3f4";
            $merchantKey = '$2y$10$LApDyMV5TCB8uFiNnHl5QOyFfxY3.sGZgivBfLFUbk0PjUs4g25EK';

            $token = getToken($app_id, $app_secret);

            echo $token;

            function getToken($app_id, $app_secret)
            {
                $baseUrl = "https://testapp.platformode.com.tr/ccpayment/api/token";

                $data = array(
                    'app_id' => $app_id,
                    'app_secret' => $app_secret
                );

                $jsonData = json_encode($data);

                $ch = curl_init($baseUrl);

                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                ));

                $response = curl_exec($ch);

                if (curl_errno($ch)) {
                    return 'Hata: ' . curl_error($ch);
                } else {
                    $decodedResponse = json_decode($response, true);

                    if ($decodedResponse['status_code'] == 100) {
                        echo "İşlem Başarılı <br><br>";
                        return $response;
                    } else {
                        echo "İşlem Başarısız <br><br>";
                        return $response;
                    }
                }

                curl_close($ch);
            }
        }

        ?>
    </div>
    <?php include 'footer.php'; ?>
</body>

</html>