<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parametreler</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .container {
            flex: 1;

        }

        .navbar-custom {
            background-color: #1b0565;
        }

        .navbar-custom .nav-link {
            color: white !important;
        }

        .navbar-brand {
            flex-grow: 1;
            text-align: center;
        }

        .navbar-nav {
            flex-direction: row;
            justify-content: center;
            width: 100%;
        }

        footer {
            background-color: #1b0565;
            color: white;
        }

        .btn-custom {
            background-color: #1b0565;
            color: white;
        }

        .btn {
            background-color: #1b0565;
            color: white;
            margin-bottom: 10px;
        }


        td {
            word-wrap: break-word;
            word-break: break-word;
            max-width: 250px;
        }
    </style>
</head>

<body>



<?php include "nav.php" ?>
    <div class="container mt-4">

        <h2>Parametreler</h2>

        <table class="table">
                    <tr>
                        <td>Fatura ID:</td>
                        <td><label  >Test9861</label></td>
                    </tr>
                    <tr>
                        <td>Kart Sahibi Adı:</td>
                        <td><label >John Dao</label></td>
                    </tr>
                    <tr>
                        <td>Kart Numarası:</td>
                        <td><label  >4155141122223339</label></td>
                    </tr>
                    <tr>
                        <td>Son Kullanım Ayı:</td>
                        <td><label >12</label></td>
                    </tr>
                    <tr>
                        <td>Son Kullanım Yılı:</td>
                        <td><label  >25</label></td>
                    </tr>
                    <tr>
                        <td>CVV:</td>
                        <td><label  >555</label></td>
                    </tr>
                    <tr>
                        <td>Para Birimi:</td>
                        <td><label  >TRY</label></td>
                    </tr>
                    <tr>
                        <td>Ürünler:</td>
                        <td><label  >[{"name":"Item3","price":22,"quantity":1,"description":"item3 description"}]</label></td>
                    </tr>
                    <tr>
                        <td>MerchantKey:</td>
                        <td><label  >$2y$10$LApDyMV5TCB8uFiNnHl5QOyFfxY3.sGZgivBfLFUbk0PjUs4g25EK</label></td>
                    </tr>
                    <tr>
                        <td>Taksit Sayısı:</td>
                        <td><label  >1</label></td>
                    </tr>
                </table>

        
    </div>

    <?php include 'footer.php'; ?>

</body>

</html>