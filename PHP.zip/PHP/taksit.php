<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>Taksit Gösterme Entegrasyonu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .container {
            flex: 1;
        }

        .navbar-custom {
            background-color: #1b0565;
        }

        .navbar-custom .nav-link {
            color: white !important;
        }

        .navbar-brand {
            flex-grow: 1;
            text-align: center;
        }

        .navbar-nav {
            flex-direction: row;
            justify-content: center;
            width: 100%;
        }

        footer {
            background-color: #1b0565;
            color: white;
        }

        .btn-custom {
            background-color: #1b0565;
            color: white;
        }

        .btn {
            background-color: #1b0565;
            color: white;
            margin-bottom: 10px;
        }

        td {
            word-wrap: break-word;
            word-break: break-word;
            max-width: 250px;
        }

        .logo-img {

            width: 100px;

        }

        /* Custom styles for title and table */
        .section-title {
            font-size: 2.5rem;
            text-align: center;
            font-weight: bold;
            margin-top: 10px;
            margin-bottom: 50px;
        }

        .table-container {
            display: flex;
            justify-content: center;

        }

        .table {
            width: 80%;
            max-width: 1000px;
            margin: 0 auto;
            margin-bottom: 100px;
        }
    </style>
</head>

<body>
    <?php include "nav.php" ?>
    <div class="container mt-4 ">
        <?php include 'style.php'; ?>
        <h2>Kredi Kartı Taksit Gösterme</h2>

        <form method="post" onsubmit="return validateCardNumber()">
            <label for="credit_card" class="mt-2">Kredi Kartı Numarası (İlk 6 Hane):</label>
            <input type="text" id="credit_card" name="credit_card" class="form-control" onkeypress="return (event.charCode !=8 && event.charCode ==0 || ( event.charCode == 46 || (event.charCode >= 48 && event.charCode <= 57)))" maxlength="6" required
                pattern="\d{6}" title="Sadece sayılar girin ve 6 hane olmalı"><br><br>

            <button type="submit" name="process_payment" class="btns">Taksit Seçeneklerini Göster</button>
        </form>
    </div>

    <?php
    if (isset($_POST['process_payment'])) {
        $credit_card = $_POST['credit_card'];  // Kredi kartı numarasını al

        // Kart programı ve banka ilişkisi
        $cardInfo = getCardInfo($credit_card);

        if ($cardInfo) {
            // Kart bilgilerini ve taksit seçeneklerini göster
            echo "<h3 class='section-title'>Kart Programı ve Taksit Seçenekleri</h3>";
            echo "<div class='table-container'>";  // Wrapper div for centering
            echo "<table class='table table-bordered text-center'>";
            echo "<tr><th>Kart Programı</th><th>Bankalar</th><th>Logo</th><th>Taksit Seçenekleri</th></tr>";
            echo "<tr>";
            echo "<td>" . $cardInfo['card_program'] . "</td>";
            echo "<td>" . implode(", ", $cardInfo['banks']) . "</td>";
            echo "<td><img src='" . $cardInfo['logo'] . "' alt='Logo' class='logo-img'></td>";
            echo "<td>" . implode(", ", $cardInfo['installments']) . "</td>";
            echo "</tr>";
            echo "</table>";
            echo "</div>";  // End of table-container
        } else {
            echo "<p><strong>Hata:</strong> Kart bilgisi bulunamadı. Lütfen geçerli bir kart numarası giriniz.</p>";
        }
    }

    function getCardInfo($cardNumber)
    {
        // Kart numarasının ilk 6 hanesini al (BIN numarası)
        $bin = intval(substr($cardNumber, 0, 6));

        // Kart bilgilerini tanımla
        $cardData = [
            'Axess' => [
                'bin_ranges' => [[413252, 420000, 435509]], // Axess'e ait BIN numarası aralıkları
                'banks' => ['Akbank', 'Odeabank'],
                'installments' => ['3', '6', '9', '12'],
                'logo' => 'axess-logo.png'  // Logo yolu
            ],
            'Bankkart' => [
                'bin_ranges' => [[424106, 424274]], // Bankkart'a ait BIN numarası aralıkları
                'banks' => ['Ziraat Bankası', 'Ziraat Katılım'],
                'installments' => ['3', '6', '9', '12'],
                'logo' => 'bankkart-logo.jpg'  // Logo yolu
            ],
            'Bonus' => [
                'bin_ranges' => [[550200, 550299]], // Bonus'a ait BIN numarası aralıkları
                'banks' => ['Alternatifbank', 'Denizbank', 'Fibabanka', 'ING', 'Garanti BBVA', 'PTT Bank', 'Şekerbank', 'TEB', 'Türkiye Finans'],
                'installments' => ['3', '6', '9', '12'],
                'logo' => 'bonus-logo.png'  // Logo yolu
            ],
            'CardFinans' => [
                'bin_ranges' => [[424275, 424280]], // CardFinans'a ait BIN numarası aralıkları
                'banks' => ['QNB Finansbank'],
                'installments' => ['3', '6', '9', '12'],
                'logo' => 'cardfinans-logo.png'  // Logo yolu
            ],
            'Maximum' => [
                'bin_ranges' => [[452215, 452220]], // Maximum'a ait BIN numarası aralıkları
                'banks' => ['Türkiye İş Bankası'],
                'installments' => ['3', '6', '9', '12'],
                'logo' => 'maximum-logo.jpg'  // Logo yolu
            ],
            'Paraf' => [
                'bin_ranges' => [[500001, 530099]], // Paraf'a ait BIN numarası aralıkları
                'banks' => ['Halkbank'],
                'installments' => ['3', '6', '9', '12'],
                'logo' => 'paraf-logo.jpg'  // Logo yolu
            ],
            'Sağlam Kart' => [
                'bin_ranges' => [[424105, 424110]], // Sağlam Kart'a ait BIN numarası aralıkları
                'banks' => ['Kuveyt Türk'],
                'installments' => ['3', '6', '9', '12'],
                'logo' => 'saglam-logo.jpg'  // Logo yolu
            ],
            'World Card' => [
                'bin_ranges' => [[490000, 500000]], // World Card'a ait BIN numarası aralıkları
                'banks' => ['Anadolubank', 'Albaraka Türk', 'Vakıfbank', 'Yapı Kredi'],
                'installments' => ['3', '6', '9', '12'],
                'logo' => 'worldcard-logo.png'  // Logo yolu
            ]
        ];

        // BIN numarasına göre doğru kartı bul
        foreach ($cardData as $cardProgram => $data) {
            foreach ($data['bin_ranges'] as $range) {
                if ($bin >= $range[0] && $bin <= $range[1]) {
                    return [
                        'card_program' => $cardProgram,
                        'banks' => $data['banks'],
                        'installments' => $data['installments'],
                        'logo' => $data['logo']
                    ];
                }
            }
        }

        return null; // Kart numarasına ait bilgi bulunamadıysa null döndür
    }


    ?>

    <footer class="py-3">
        <div class="container text-center">
            <span class="text-light">© 2024 Platform Ödeme Hizmetleri ve Elektronik Para A.Ş.</span>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>