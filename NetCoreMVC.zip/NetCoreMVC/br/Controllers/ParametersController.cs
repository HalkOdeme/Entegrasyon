﻿using Microsoft.AspNetCore.Mvc;

namespace HalkOdePaymentIntegration.Controllers
{
    public class ParametersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
