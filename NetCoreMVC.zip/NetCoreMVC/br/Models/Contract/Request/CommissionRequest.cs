﻿namespace HalkOdePaymentIntegration.Contract.Request
{
    public class CommissionRequest
    {
        public string currency_code { get; set; }
    }

}
