﻿namespace HalkOdePaymentIntegration.Contract.Request
{
    public class AllTransactionRequest
    {
        public string merchant_key { get; set; }
    }
}